import mysql.connector as c

#establish the connection from python to mysql db 
con = c.connect(host='localhost',user='root',password='root',database='py_test')

#link between sql command to sql server
cur = con.cursor()

def readdata():
          
     cur.execute('select * from users')

     data = cur.fetchall()

     for r in data:
          print(r)
          

def writedata():
     #cur.execute("insert into  users(id,name) values(11,'rahul')")
     eid = input('enter data :')
     ename = input('enter name :')
     
     #cur.execute("insert into  users(id,name) values(11,'rahul')")
     #"+eid+"
     cur.execute("insert into  users(id,name) values("+eid+",'"+ename+"')")
     

     con.commit()
     print('data is saved')

writedata()
readdata()

     



