def writeToFile():
     #new file will be create if file not exist, and file will be overwritten if exist 
     f = open(r'C:\Users\vkumar15\Desktop\out.txt','w')

     for i in range(1,5):
          d =input('enter data :')
          f.write(d+'\n')

          
     f.close() # to save the file
     print('data is saved..')
     
     
def appendToFile():
     #new file will be create if file not exist, and file will be overwritten if exist 
     f = open(r'C:\Users\vkumar15\Desktop\out.txt','a')

     for i in range(1,5):
          d =input('enter data :')
          f.write(d+'\n')

          
     f.close() # to save the file
     print('data is saved..')
     
     
          
     
def readdata():
     
          f = open(r'C:\Users\vkumar15\Desktop\1. Python Sesson -Day -01.txt','r')
          #print(f)

          #print(f.read())
          #print(f.readline())
          #print(f.readline())
          #print(f.readline())
          #print(f.readline())

          data = f.readlines()
          lc = 0

          #wap to get word count
          wc=0
          #wap to get particular word count
          pwc = 0

          for r in data:
               print(r)
               if r != '\n':
                    lc = lc+1

               #wc count
               s = r.split(' ')
               wc += len(s)
               for w in s:
                    if w =='is':
                         pwc+=1


          #count of rows
          print(len(data))
          print(lc)
          print(wc)
          print(pwc)      

#writeToFile()
appendToFile()


