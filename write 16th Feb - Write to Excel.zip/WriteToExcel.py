import xlwt 
from xlwt import Workbook

wb = Workbook()  #create object of class


style = xlwt.easyxf('font: bold 1, color red;')


# add_sheet is used to create sheet. 
sheet1 = wb.add_sheet('Customer')
w = wb.get_sheet('Customer')

for i in range(0,5):
     cid = input('enter cid :')
     cname = input('enter cid :')

     w.write(str(int(w.cell_value())*100))
     
     
     sheet1.write(i, 0, cid,style)
     sheet1.write(i, 1, cname)
     

wb.save(r'C:\Users\vkumar15\Desktop\Desktop - Raman\customers.xls')

print("data is saved")





