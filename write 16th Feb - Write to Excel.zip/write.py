import xlwt
from xlwt import Workbook
wb=Workbook()

sheet=wb.add_sheet('dev')
w = wb.get_sheet('dev')
for i in range(0,5):
     #s1=input('Enter subject name')
     #s2=input('Enter Marks ')

     col = ['subject ','marks ']
     s=0
     for j in range(0,2):
          s=input('Enter '+ col[j] )
          sheet.write(i,j,s)
          
     #sheet.write(i,1,s2)
     marks=int(s)
     if marks>90:
          w.write(i,3,'A')
     elif marks>=80:
          w.write(i,3,'B')
     elif marks>=70:
          w.write(i,3,'C')
     elif marks>=50:
          w.write(i,3,'D')
     else:
          w.write(i,3,'Fail')



     
wb.save(r'C:\Users\vkumar15\Desktop\Desktop - Raman\dev.xls')
print('data is saved')
