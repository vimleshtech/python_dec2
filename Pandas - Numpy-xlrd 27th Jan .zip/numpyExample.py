import numpy as np

a = np.arange(5)
print(a)


a = np.arange(10,15)
print(a)


a = np.arange(10,15,.5,dtype = float)
print(a)

#convert list to array
a = np.array([11,22,33])
print(a)


#
a = np.array([[1, 2], [3, 4]])
print(a)


#
a = np.array([1, 2, 3,4,5], ndmin = 2)
print(a)

a = np.array([1, 2, 3,4,5], ndmin = 3)
print(a)



#
dt = np.dtype([('age',np.int8)])

a = np.array([(10,),(20,),(30,)], dtype = dt)
print(a)
print (a['age'])



##reshape
a = np.array([[1,2,3],[4,5,6]])
print(a.shape)

a.shape = (3,2) 
print (a )

















