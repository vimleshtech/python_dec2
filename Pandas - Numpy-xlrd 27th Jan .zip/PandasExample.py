import pandas as pd


#read from .csv file
df = pd.read_csv(r'C:\Users\vkumar15\Desktop\emp.csv')

print(df) #print data frame 
print(df.columns) #show list of columns
print(df.index) #show row index
print(df.shape)  #show dimenssion (row,col)


#print top given # of rows
print(df.head(n=2))
print(df.head(2))


#print buttom given # of rows
print(df.tail(3))


#read particular column
print(df['name'])

#convert dataframe to list
data = df.values
print(data)

#show selected colums
print(data[:,2])
print(data[:,2:4])

#show selected rows
print(data[1,:]) 
print(data[1:3,:])

print(data[1:3,2:4])   

#group by  # is also called/known as distribuation 
print(df.groupby('gender').size())
print(df.groupby('gender').sum())
print(df.groupby('gender').sum()['salary'])
print(df.groupby('gender').max())
print(df.groupby('gender').min())

#sorting / arrange in ascending or descending order
print(df.sort_values('name',ascending=True))
print(df.sort_values('salary',ascending=False))


ndf =df.sort_values('salary',ascending=False)
##write back to another csv

ndf.to_csv(r'C:\Users\vkumar15\Desktop\emp_sorted.csv')
print('data is saved in csv')













     





