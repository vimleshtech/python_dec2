import xlrd

book = xlrd.open_workbook(r'C:\Users\vkumar15\Desktop\Offset Unprocessed_20190121.xlsx')

sheet = book.sheet_by_index(1)
print(sheet)


print(sheet.nrows)
print(sheet.ncols)
print(sheet.cell_value(0,0))

for  x in range(0,sheet.nrows):
          print(sheet.cell_value(x,0))
          print(sheet.cell_value(x,1))
          print(sheet.cell_value(x,2))
          print(sheet.cell_value(x,3))
          print(sheet.cell_value(x,4))
     


