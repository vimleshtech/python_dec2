import pandas as pd

#create new dataframe
df = pd.DataFrame()
print(df)


#
name =['RAMAN','monika','jyoti']
sal = [1111,22222,33434]
a = pd.DataFrame(data=name)
print(a)


#create dataframe from list and dict
df = pd.DataFrame(data={'eid':[1,3,5],'name':name,'gender':['m','f','f'],'sal':sal})
print(df)




out  = df.loc[df['gender']=='m']
print(out)


out  = df.loc[df['gender']=='f']
print(out)

out  = df.loc[df['sal']>=22222]
print(out)



