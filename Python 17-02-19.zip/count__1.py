o =['a','a','b','c','b']


uq=[]
for i in o:

    if i not in uq:
        uq.append(i)
a= o.count('a')
b= o.count('b')
c= o.count('c')
print(a,b,c)
#print(uq)
'''
counta=0
countb=0
countc=0
for i in o:
    if i=='a':
        counta=counta+1
    elif i=='b':
        countb=countb+1
    else:
        countc=countc+1
print(" no. of a: ",counta,"\n no. of b: ",countb,"\n no. of c: ",countc)
    
'''



        
    
