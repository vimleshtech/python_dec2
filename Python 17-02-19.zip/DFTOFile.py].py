import pandas

#create blank dataframe
o = pandas.DataFrame()
print(o)

#
eid  = [1,2,3]
ename = ['abcd','xyz','ab']
sal  = [13333,244444,333333]

df1 = pandas.DataFrame(data={'eid':eid,'name':ename,'sal':sal})
print(df1)


eid  = [1,2,3]
att = ['p','a','p']


df2 = pandas.DataFrame(data={'eid':eid,'a_status':att})
print(df2)

#####convert data frame to list
d1 = df1.values
d2 = df2.values
print(d1)
print(d2)

c1 = d1[:,0] # : - all rows , 0 first col
c2 = d1[:,1]
c3 =  d1[:,2]
c4 =  d2[:,1]


df = pandas.DataFrame(data={'eid':c1,'name':c2,'sal':c3 ,'a_status':c4})

print(df)






















