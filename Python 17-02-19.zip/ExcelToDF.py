import pandas as pd


src =R"C:\Users\KR872923\Desktop\IASRI OS 26 Mn.xlsx"
o =   pd.read_excel(src)
print(o)


print(o.groupby('BOCRemarks').size())


print(o.groupby('BOCRemarks').sum()['OutstandingAmount'])



#
o =['a','a','b','c','b']



