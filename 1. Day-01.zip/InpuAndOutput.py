
#wap to get sum of all even and odd numbers between two given range
a = int(input('enter first no. :'))
b = int(input('enter 2nd no. :'))

se =0
so =0

while a<=b:
    if a%2==0:
        se =se+a
    else:
        so = so+a
    a=a+1
print(se,so)
