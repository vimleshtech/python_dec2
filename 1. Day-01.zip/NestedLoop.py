for r in range(2,20,2):
    print('(',end='')
    
    for c in range(2,r+1,):
        if c<r:
            print(c,"+",end='')
        else:
            print(c,end='')
    print(')+')
                    
