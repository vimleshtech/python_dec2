i =1 # init / start from 
while i<10:  #condition
    print(i,end=',')
    i=i+1

#print in reverse order
i =10
while i>0:
    print(i)
    i =i-1
    
    

#print table of 3
i=1
while i<=10 :
    print(3,'*',i,'=',i*3)
    i=i+1

#print all even no between 1 to 30
i=2
while i<=30:
    print(i)
    i+=2
    






    
    

