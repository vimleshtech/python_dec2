s = int(input('enter sale amount :'))


#if condition without else 
tax =0
if s>1000:
    tax = s *.18

total = s+tax
print(total)


#############
s = int(input('enter sale amount :'))

#if else 
tax =0
if s>1000:
    tax = s *.18
else:
    tax = s*.05
    
total = s+tax
print(total)


#-if elif elif ... else condition / ladder if else
a = int(input('enter data:'))
b = int(input('enter data :'))
c = int(input('enter data :'))

if a>b and a>c:
    print('a is gt')
elif b>a and b>c:
    print('b is gt')
else:
    print('c is gt')

#-Nested if else /if inside if
if a>b:
    if a>c:
        print('a is gt')
    else:
        print('c is gt')
else:
    if b<c:
        print('b is gt')
    else:
        print('c is gt')
        







