i =1
while i>0:
    print(i)
    
    if i % 5 ==0:
        break
    i = i+1
    
    

i =0
while i<10:
    
     i = i+1
    if i % 3 ==0:
        continue
    print(i)
   
