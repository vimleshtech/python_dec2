for x in range(1,10):
    print( 2**x,end=',')
print() 
for x in range(1,10):
    print( x**2+x-1,end=',')
    
    
    
     
