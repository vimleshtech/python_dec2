from mymodel import *

data= [['nan','nan',11,222,33],[55,1,11,222,33],['nan',11,222,33]]


for d in data:
    #print(get_mean(d))
    #print(prepare_data(d))
    print(prepare_data(d,10))
    

