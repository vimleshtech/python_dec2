import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from tweet_Test import gettweet

'''
res = gettweet()
print(res)
'''

positive=[20,30,10]
negative=[30,40,10]
neutral=[50,30,80]
'''
for i in range(0,len(res)):
    positive.append(res[i][0])
    negative.append(res[i][1])
    neutral.append(res[i][2])
'''



# data to plot
n_groups = 3

 
# create plot
fig, ax = plt.subplots()
index = np.arange(n_groups)
print(index)

bar_width = 0.30
opacity = 0.6
 
rects1 = plt.bar(index, positive, bar_width,
                 alpha=opacity,
                 color='g',
                 label='positive')
 
rects2 = plt.bar(index + bar_width, negative, bar_width,
                 alpha=opacity,
                 color='r',
                 label='negative')

rects3 = plt.bar(index + bar_width+ bar_width, neutral, bar_width,
                 alpha=opacity,
                 color='b',
                 label='neutral')

 
plt.xlabel('Persons')
plt.ylabel('Sentiments')
plt.title('Twitter sentiment analysis')
plt.xticks(index + bar_width, ('Donald Trump', 'Narendra Modi', 'Rahul Gandhi'))
plt.legend()
 
plt.tight_layout()
plt.show()

