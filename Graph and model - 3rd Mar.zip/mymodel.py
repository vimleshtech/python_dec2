

def clean_data(col):
    data = []
    for d in col:
        if d != 'nan':
            data.append(d)


    return data

def get_mean(col):
    col =  clean_data(col)
    m = 0
    for d in col:
        m += d

    return m/len(col)


def prepare_data(col,default=0):
    if default == 0:
        m = get_mean(col)
    else:
        m = default
        print(m)
    for i in range(0,len(col)):
        if col[i] == 'nan':
            col[i]=m
    return col








    




    
    
    
